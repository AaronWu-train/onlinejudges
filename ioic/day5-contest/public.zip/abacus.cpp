#include "lib0046.h"

// definition of operations (already defined in header)
// const int OP_LESS = 0;
// const int OP_LEQ = 1;
// const int OP_GREATER = 2;
// const int OP_GEQ = 3;

// const int OP_AND = 0;
// const int OP_OR = 1;
// const int OP_XOR = 2;
// const int OP_ADD = 3;
// const int OP_SUBTRACT = 4;

// constant strings that might be useful
std::string zero_str = "00000000000000000000000000000000";
std::string one_str = "00000000000000000000000010000000";
std::string sign_str = "00000000000000000000000000000001";
std::string full_str = "11111111111111111111111111111111";
std::string unit_str = "10000000000000000000000000000000";

void solve(int problem_type) {
	if (problem_type == 1) { 		// double
		left(0, 0, 1);
		calculate(0, 1, OP_OR, 2);
		print(2);
		answer(1);
	} else if (problem_type == 2) { // square
		
	} else if (problem_type == 3) { // sine

	} else { 						// log
			 
	}
}
