#include <vector>

std::vector<int> get_ranking(int N);
int get_downvote(std::vector<int> g);